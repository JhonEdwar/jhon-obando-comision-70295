export default class BusDTO {
    constructor(business){
        this.firstName = business.firstName
        this.email = business.email
    }
}